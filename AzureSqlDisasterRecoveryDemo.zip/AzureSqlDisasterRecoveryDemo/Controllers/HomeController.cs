﻿using AzureSqlDisasterRecoveryDemo.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace AzureSqlDisasterRecoveryDemo.Controllers
{
    public class HomeController : Controller
    {
       
        public ActionResult Index()
        {
            var model = new Models.HomeModel();

            model.IsDataFromPrimaryReplica = IsServerConnected();

            using (Models.AdventureWorks2016CTP3Entities entities = new Models.AdventureWorks2016CTP3Entities())
            {
                model.OrderTrackingEvents = entities.OrderTrackings.SqlQuery(@"select * from (select top 5 OrderTrackingID, SalesOrderID,CarrierTrackingNumber,TrackingEventID,EventDetails,EventDateTime from Sales.OrderTracking where eventdatetime > '01-01-2014' order by EventDateTime desc) r1
                                                                                 union all
                                                                                select * from (select top 5 OrderTrackingID, SalesOrderID, CarrierTrackingNumber, TrackingEventID, EventDetails, EventDateTime from Sales.OrderTracking where eventdatetime < '01-01-2014' order by EventDateTime) r2").ToList();

                model.TotalSpaceUsed =  entities.Database.SqlQuery<SQLUseSpace>(@"EXEC sp_spaceused N'Sales.OrderTracking', @mode = 'ALL'").Single();
                model.RemoteSpaceUsed = entities.Database.SqlQuery<SQLUseSpace>(@"EXEC sp_spaceused N'Sales.OrderTracking', @mode = 'REMOTE_ONLY'").Single();
                model.LocalSpaceUsed = entities.Database.SqlQuery<SQLUseSpace>(@"EXEC sp_spaceused N'Sales.OrderTracking', @mode = 'LOCAL_ONLY'").Single();
            }

            return View(model);
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        private bool IsServerConnected()
        {
            using (var l_oConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["SQLAlwaysOnConnection"].ConnectionString))
            {
                try
                {
                    l_oConnection.Open();
                    return true;
                }
                catch (SqlException)
                {
                    return false;
                }
            }
        }

    }
}