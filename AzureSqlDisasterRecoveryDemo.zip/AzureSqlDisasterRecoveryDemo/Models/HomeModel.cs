﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AzureSqlDisasterRecoveryDemo.Models
{
    public class HomeModel
    {
        public HomeModel()
        {
            OrderTrackingEvents = new List<OrderTracking>();
        }

        public List<OrderTracking> OrderTrackingEvents { get; set; }

        public bool IsDataFromPrimaryReplica { get; set; }

        public SQLUseSpace TotalSpaceUsed { get; set; }
        public SQLUseSpace LocalSpaceUsed { get; set; }
        public SQLUseSpace RemoteSpaceUsed { get; set; }
    }

    public class SQLUseSpace
    {
        public string name { get; set; }

        public string rows { get; set; }

        public string data { get; set; }

        public string reserved { get; set; }

        public string index_size { get; set; }

        public string unused { get; set; }
    }
}